package exr.at.com.allahnames;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.re);
        mLayoutManager = new LinearLayoutManager(MainActivity.this);
       /* RecyclerView.LayoutManager la = new StaggeredGridLayoutManager(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS, StaggeredGridLayoutManager.VERTICAL);*/
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        ArrayList<NameModel> arrayList=new ArrayList<NameModel>();
        arrayList.add(new NameModel("الله","আল্লাহ্‌","The almighty","1.Allah",R.raw.allah));
        arrayList.add(new NameModel("الرحيم","আর রহিম","The Most Merciful","2.Ar-Rahim",R.raw.rahim));
        arrayList.add(new NameModel("الرحمن ","আর রহমান","The Most or Entirely Merciful","3.Ar-Rahman",R.raw.rahman));
        arrayList.add(new NameModel("الجبار","আল জাব্বার","Supreme Power","4.Al-Jabbar",R.raw.jabbar));
        arrayList.add(new NameModel("العزيز","আল ʿআজিজ","Powerful","5.Al-Aziz",R.raw.aziz));

        arrayList.add(new NameModel("المؤمن","আল মুʿমিন","The Giver","6.Al-Mu'min",R.raw.mumin));
        arrayList.add(new NameModel("السلام","আস সালাম","The Giver of Peace","7.As-Salam",R.raw.salam));
        arrayList.add(new NameModel("القدوس","আল কুদ্দুস","Sacred","8.Al-Quddus",R.raw.quddus));
        arrayList.add(new NameModel("الملك","আল মালিক","The King","9.Al-Malik",R.raw.malik));

        arrayList.add(new NameModel("الوهاب","আল ওয়াহহাব","Great Donor","10.Al-Wahhab",R.raw.wahhab));
        arrayList.add(new NameModel("القهار","আল কাহহার","Overcomer","11.Al-Qahhar",R.raw.qahhar));
        arrayList.add(new NameModel("الغفار","আল গাফফার ","Absolute Forgiver","12.Al-Ghaffar",R.raw.ghaffar));
        arrayList.add(new NameModel("المصور","আল মুসাওবির","The Fashioner","13.Al-Musawwir",R.raw.musawwir));
        arrayList.add(new NameModel("البارئ","আল বারী","The Initiator","14.Al-Bari'",R.raw.bari));
        arrayList.add(new NameModel("الخالق","আল খালিক ","The Creator","15.Al-Khaliq",R.raw.khaliq));
        arrayList.add(new NameModel("المتكبر","আল মুতাকাব্বির ","Supreme","16.Al-Mutakabbir",R.raw.mutakabbir));
        arrayList.add(new NameModel("الرافع","আর রাফি","The Exalter","17.Ar-Rafi",R.raw.rafi));
        arrayList.add(new NameModel("الخافض","আল খাফিদ ","The Abaser","18.Al-Khafid",R.raw.khafid));
        arrayList.add(new NameModel("الباسط","আল বাসিত ","Generous Provider","19.Al-Basit",R.raw.basit));

        arrayList.add(new NameModel("القابض","আল কাবিদ","The Restrainer","20.Al-Qabid",R.raw.qabid));
        arrayList.add(new NameModel("العليم","আল আলীম ","All-Knower","21.Al-`Alim",R.raw.alim));
        arrayList.add(new NameModel("الفتاح","আল ফাত্তাহ ","The Victory Giver","22.Al-Fattah",R.raw.fattah));
        arrayList.add(new NameModel("الرزاق","আর রাজ্জাক","The Provider","23.Ar-Razzaq",R.raw.razzaq));
        arrayList.add(new NameModel("اللطيف","আল লাতিফ ","The Gentle","24.Al-Latif",R.raw.latif));
        arrayList.add(new NameModel("العدل","আল ʿআদি","The Just","25.Al-`Adl",R.raw.adl));
        arrayList.add(new NameModel("الحكم","আল হাকাম","Arbitrator","26.Al-Hakam",R.raw.hakam));
        arrayList.add(new NameModel("البصير","আল বাসির","The All-Seeing","27.Al-Basir",R.raw.basir));
        arrayList.add(new NameModel("السميع","আস সামী","The Hearing","28.As-Sami",R.raw.sami));
        arrayList.add(new NameModel("المذل","আল মুযিল ","The Giver of Dishonor","29.Al-Mudhill",R.raw.mudhill));

        arrayList.add(new NameModel("المعيد","আল মুʿইদ","The Restorer","30.Al-Mu'id",R.raw.muid));
        arrayList.add(new NameModel("الكبير","আল কাবীর","Most Great","31.Al-Kabir",R.raw.kabir));
        arrayList.add(new NameModel("العلي","আল ʿআলী","Most High","32.Al-Ali",R.raw.ali));
        arrayList.add(new NameModel("الشكور","আশ শাকুর ","The Grateful","33.Ash-Shakur",R.raw.shakur));
        arrayList.add(new NameModel("الغفور","আল গফুর","The Ever-Forgiving","34.Al-Ghafur",R.raw.ghafur));
        arrayList.add(new NameModel("العظيم","আল ʿআজীম ","Most Supreme","35.Al-Azim",R.raw.azim));
        arrayList.add(new NameModel("الحليم","আল হালীম","The Forbearing","36.Al-Halim",R.raw.halim));
        arrayList.add(new NameModel("الخبير","আল খাবীর","The All-Aware","37.Al-Khabir",R.raw.khabir));
        arrayList.add(new NameModel("المجيب","আল মুজিব","The Responsive","38.Al-Mujib",R.raw.mujib));
        arrayList.add(new NameModel("الرقيب","আর রাকীব ","Observer","39.Ar-Raqib",R.raw.raqib));

        arrayList.add(new NameModel("الكريم","আল কারীম ","Generous","40.Al-Karim",R.raw.karim));
        arrayList.add(new NameModel("الجليل","আল জালীল","The Majestic","41.Al-Jalil",R.raw.jalil));
        arrayList.add(new NameModel("الحسيب","আল হাসীব","The Bringer of Judgment","42.Al-Hasib",R.raw.hasib));
        arrayList.add(new NameModel("المقيت","আল মুকিত","Feeder","43.Al-Muqit",R.raw.muqit));
        arrayList.add(new NameModel("الحفيظ"," আল হাফীজ","The Preserver","44.Al-Hafiz",R.raw.hafiz));
        arrayList.add(new NameModel("الحق"," আল হাক্ক","The Truth","45.Al-Haqq",R.raw.haqq));
        arrayList.add(new NameModel("الشهيد"," আশ শাহীদ","The Witness","46.Ash-Shahid",R.raw.shahid));
        arrayList.add(new NameModel("الباعث"," আল বাইছ","Awakener","47.Al-Ba'ith",R.raw.baith));
        arrayList.add(new NameModel("المجيد"," আল মাজীদ","The All-Glorious","48.Al-Majid",R.raw.majeed));
        arrayList.add(new NameModel("الودود"," আল ওয়াদুদ ","The Affectionate","49.Al-Wadud",R.raw.wadud));

        arrayList.add(new NameModel("الحكيم"," আল হাকীম","The Wise","50.Al-Hakim",R.raw.hakim));
        arrayList.add(new NameModel("الواسع"," আল ওয়াসি","All-Embracing","51.Al-Wasi",R.raw.wasi));
        arrayList.add(new NameModel("المبدئ","আল মুবদী ","The Producer","52.Al-Mubdi'",R.raw.mubdi));
        arrayList.add(new NameModel("المحصى"," আল মুহসী  ","The Accounter","53.Al-Muhsi",R.raw.muhsi));
        arrayList.add(new NameModel("الحميد"," আল হামিদ ","The All Praiseworthy","54.Al-Hamid",R.raw.hamid));
        arrayList.add(new NameModel("الولى"," আল ওয়ালী ","Helper ","55.Al-Waliyy",R.raw.wali));
        arrayList.add(new NameModel("المتين"," আল মাতীন","The Firm","56.Al-Matin",R.raw.matin));
        arrayList.add(new NameModel("القوى"," আল কায়ুয়ী","The Strong","57.Al-Qawiyy",R.raw.qawi));
        arrayList.add(new NameModel("الوكيل","আল ওয়াকীল ","The Advocate","58.Al-Wakil",R.raw.wakil));
        arrayList.add(new NameModel("المجيد"," আল মাজিদ ","The Illustrious","59.Al-Majid",R.raw.majid));

        arrayList.add(new NameModel("الواجد"," আল ওয়াজিদ","The Perceiver","60.Al-Wajid",R.raw.wajid));
        arrayList.add(new NameModel("القيوم","আল কায়্যুম ","The Independent","61.Al-Qayyum",R.raw.qayyum));
        arrayList.add(new NameModel("الحي","আল হায়্যু","The Living","62.Al-Hayy",R.raw.hayy));
        arrayList.add(new NameModel("المميت","আল মুমীত","The Bringer of Death","63.Al-Mumit",R.raw.mumit));
        arrayList.add(new NameModel("المحيى"," আল মুহয়ী","The Giver of Life","64.Al-Muhyi",R.raw.muhyi));
        arrayList.add(new NameModel("المعيد"," আল মুʿঈদ","The Restorer","65.Al-Mu'id",R.raw.muid));
        arrayList.add(new NameModel("الأول","আল আওয়াল","The First","66.Al-Awwal",R.raw.awwal));
        arrayList.add(new NameModel("المؤخر","আল মুʾয়াখখীর","The Delayer","67.Al-Mu'akhkhir",R.raw.muakhkhir));
        arrayList.add(new NameModel("المقدم"," আল মুকাদ্দিম","The Expediter","68.Al-Muqaddim",R.raw.muqaddim));
        arrayList.add(new NameModel("المقتدر"," আল মুকতাদীর","The Determiner","69.Al-Muqtadir",R.raw.muqtadir));

        arrayList.add(new NameModel("القادر"," আল কাদীর","The All-Powerful","70.Al-Qadir",R.raw.qadir));
        arrayList.add(new NameModel("الصمد"," আস সামাদ","The Eternal","71.As-Samad",R.raw.samad));
        arrayList.add(new NameModel("الواحد"," আল ওয়াহিদ","The Single","72.Al-Wahid",R.raw.wahid));
        arrayList.add(new NameModel("التواب"," আত তাওয়াব","The Ever-Returning","73.At-Tawwab",R.raw.tawwab));
        arrayList.add(new NameModel("البر"," আল বার্র ","The Good","74.Al-Barr",R.raw.barr));
        arrayList.add(new NameModel("المتعالي","আল মুতাʿআলী","The Most High","75.Al-Muta'ali",R.raw.muta_ali));
        arrayList.add(new NameModel("الوالي","আল ওয়ালী","The Patron","76.Al-Wali",R.raw.waliy));
        arrayList.add(new NameModel("الباطن","আল বাতিন","The Hidden","77.Al-Batin",R.raw.batin));
        arrayList.add(new NameModel("الظاهر","আল জাহির ","The Manifest","78.Az-Zahir",R.raw.zahir));
        arrayList.add(new NameModel("الأخر","আল আখির","The Endless","79.Al-Akhir",R.raw.akhir));

        arrayList.add(new NameModel("المقسط","আল মুকসিত","The Equitable","80.Al-Muqsit",R.raw.muqsit));
        arrayList.add(new NameModel(" الجلال والإكرام"," যুল জালাল ওয়ালইকরাম","Lord of Majesty and Honour","81.Dhu-al-Jalal wa-al-Ikram",R.raw.dhu_l_jalali_wal_ikram));
        arrayList.add(new NameModel("مالك الملك"," মালিকুল মুলক","The Owner of all Sovereignty","82.Malik-al-Mulk",R.raw.malik_ul_mulk));
        arrayList.add(new NameModel("الرؤوف","আর রাʾউফ","The Kind","83.Ar-Ra'uf",R.raw.rauf));
        arrayList.add(new NameModel("العفو"," আল আʿওউফ","The Pardoner","84.Al-'Afuww",R.raw.afuw));
        arrayList.add(new NameModel("المنتقم","আল মুনতাকীম","The Avenger","85.Al-Muntaqim",R.raw.muntaqim));
        arrayList.add(new NameModel("الهادي"," আল হাদী ","The Guide","86.Al-Hadi",R.raw.hadi));
        arrayList.add(new NameModel("النافع"," আন নাফী","The Source of Good","87.An-Nafi'",R.raw.nafi));
        arrayList.add(new NameModel("الضار","আদ দারর","The Afflictor","88.Ad-Darr",R.raw.darr));
        arrayList.add(new NameModel("المانع","আল মানি","The Defender","89.Al-Mani'",R.raw.mani));

        arrayList.add(new NameModel("المغني","আল মুগনী","The Enricher","90.Al-Mughni",R.raw.mughni));
        arrayList.add(new NameModel("الغني","আল গানী","The Rich","91.Al-Ghani",R.raw.ghaniy));
        arrayList.add(new NameModel("الجامع","আল জামি","The Gatherer","92.Al-Jami'",R.raw.jami));
        arrayList.add(new NameModel("الصبور","আস সাবুর ","The Patient","93.As-Sabur",R.raw.sabur));
        arrayList.add(new NameModel("الرشيد","আর রশীদ ","The Guide to the Right Path","94.Ar-Rashid",R.raw.rashid));
        arrayList.add(new NameModel("الوارث","আল ওয়ারিছ ","The Heir","95.Al-Warith",R.raw.warith));
        arrayList.add(new NameModel("الباقي","আল বাকী","The Everlasting","96.Al-Baqi",R.raw.baqi));
        arrayList.add(new NameModel("البديع","আল বাদী","The Beautiful","97.Al-Badi",R.raw.badi));
        arrayList.add(new NameModel("النور","আন নূর","The Light","98.An-Nur",R.raw.nur));
        arrayList.add(new NameModel("المهيمن","আল মুহায়মিন","Guardian Over All","99.Al-Muhaymin",R.raw.muhaimin));



        RecyclerAdapter adapter=new RecyclerAdapter(MainActivity.this,arrayList);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(" 99 Names Of Allah ");
        builder.setMessage("Do you want to exit the app?");


        builder.setPositiveButton(" Yes ",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int id)
            {
                MainActivity.this.finish();
            }

        });
        builder.setNegativeButton(" No ",null);

        builder.show();
    }
}
